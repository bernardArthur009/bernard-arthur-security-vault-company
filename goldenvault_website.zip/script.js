// Small interactive bits. Edit freely.
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('leadForm');
form.addEventListener('submit', function(e){
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const amount = document.getElementById('amount').value.trim();
  const msg = document.getElementById('formMsg');
  if(!name || !email || !amount){
    msg.textContent = 'Please fill all fields.';
    return;
  }
  msg.textContent = 'Thanks — we received your request. (This demo does not actually send email.)';
  // In real site: post to your backend or use a service like Formspree, Netlify Forms, or a simple server endpoint.
  form.reset();
});
