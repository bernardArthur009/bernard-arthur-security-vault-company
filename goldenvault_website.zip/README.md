GoldenVault — Editable Website Template
====================================

What you get
------------
A small, mobile-friendly single-page website you can edit:
- index.html — main content and copy (easy to edit).
- styles.css — visual styling.
- script.js — small form behavior.
- CNAME-example.txt — example CNAME for custom domain.
- This package is ready for GitHub Pages / Netlify / Vercel.

How to edit
-----------
1. Open `index.html` in a text editor. Change headings, copy, images.
2. Update colors and spacing in `styles.css`.
3. Add server-side form handling or connect to Formspree / Netlify Forms. `script.js` currently only shows a demo message.

Free hosting + free domain options
---------------------------------
Option A — GitHub Pages (free)
1. Create a GitHub account if you don't have one.
2. Create a new repository, upload these files.
3. In repository Settings → Pages, set the source to the main branch. Your site will appear at `https://<your-username>.github.io/<repo-name>/`.
4. For a custom domain, set a CNAME file and configure DNS.

Option B — Netlify / Vercel (free tiers)
- Drag-and-drop the site folder in Netlify, or connect the repository. They provide a free subdomain like `goldenvault.netlify.app` or `project.vercel.app`.
- Both services support custom domains easily.

Option C — Free domain names
- If you want a free top level domain, some registrars offer free country-code domains (.tk, .ml, .ga, .cf). Search for "free domain .tk" or similar. (Free domains often come with limitations; consider a low-cost domain like .com or .co if you need reliability.)
- You can also use the free subdomains from GitHub Pages, Netlify, or Vercel (recommended for simplicity and reliability).

Deploying the site to GitHub Pages quickly
-----------------------------------------
1. Create a GitHub repo and push these files.
2. In Settings → Pages, choose the branch (main) and folder (root).
3. Wait a minute — your site will be live at `https://<username>.github.io/<repo>/`.

Custom domain (basic steps)
---------------------------
1. Buy or register a domain (or use a free one if available).
2. Add a CNAME or A records pointing to your hosting provider (GitHub Pages, Netlify, Vercel).
3. Add the domain to your hosting provider dashboard and verify.

Notes & next steps
------------------
- This template is intentionally small and easy to edit. If you'd like:
  - A multi-page site, blog, or admin panel for inventories, I can expand it.
  - Integration with payment, KYC, or inventory management, ask and I'll add a demo.
  - A ready-to-deploy GitHub repo with CI, let me know and I can prepare it.

Enjoy — edit the copy in `index.html` and the styles in `styles.css` to make it yours.
